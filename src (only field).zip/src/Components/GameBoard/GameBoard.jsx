import "./GameBoard.css";
import CreaturesRow from "../CreaturesRow/CreaturesRow";

export default function GameBoard({ playerCreatures, enemyCreatures }) {
    return (
        <>
            <div className="timer-frame">
                <div className="timer-grid">
                    — 12:34 —
                </div>

                <span className="tl"></span>
                <span className="tr"></span>
            </div>

            <div className="bg-frame">
                <div className="bg-top"/>

                <div className="bg-center">
                    <div className="field_enemy">
                        <CreaturesRow
                            creatures={enemyCreatures}
                            draggable={false}
                        />
                    </div>



                    <div className="field_user">
                        <CreaturesRow
                            creatures={playerCreatures}
                            draggable={true}
                        />
                    </div>

                </div>

                <div className="bg-bottom"/>

                {/* cut the fucking corners without goddamn triangles, stupid */}
                <span className="tl"></span>
                <span className="tr"></span>
                <span className="bl"></span>
                <span className="br"></span>

                <button className="side-button diamond"> <p>End</p>  </button>
                <span className="side-thing diamond"/>

            </div>
        </>
    );
}
