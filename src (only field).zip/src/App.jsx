import { useState } from "react";
import {
    DndContext,
    PointerSensor,
    TouchSensor,
    useSensor,
    useSensors,
    closestCenter
} from "@dnd-kit/core";

import { arrayMove } from "@dnd-kit/sortable";
import { restrictToParentElement } from "@dnd-kit/modifiers";

import GameBoard from "./components/GameBoard/GameBoard";
import { creatureStub } from "./data/creatures";

function App() {
    const [playerCreatures, setPlayerCreatures] = useState([
        creatureStub("p1", "Knight"),
        creatureStub("p2", "Archer")
    ]);

    const [enemyCreatures, setEnemyCreatures] = useState([
        creatureStub("e1", "Goblin"),
        creatureStub("e2", "Orc"),
        creatureStub("e3", "Shaman")
    ]);

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(TouchSensor)
    );

    const handleDragEnd = (event) => {
        const { active, over } = event;
        if (!over || active.id === over.id) return;

        const update = (list, setList) => {
            const oldIndex = list.findIndex(c => c.id === active.id);
            const newIndex = list.findIndex(c => c.id === over.id);
            if (oldIndex !== -1 && newIndex !== -1) {
                setList(arrayMove(list, oldIndex, newIndex));
            }
        };

        update(playerCreatures, setPlayerCreatures);
        update(enemyCreatures, setEnemyCreatures);
    };

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            modifiers={[restrictToParentElement]}
            onDragEnd={handleDragEnd}
        >
            <GameBoard
                playerCreatures={playerCreatures}
                enemyCreatures={enemyCreatures}
            />
        </DndContext>
    );
}

export default App;
