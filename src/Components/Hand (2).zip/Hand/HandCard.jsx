import { useDraggable } from "@dnd-kit/core";
import "./HandCard.css";

export default function HandCard({ card, index = 0, total = 1, dragging = false }) {
    const { attributes, listeners, setNodeRef } = useDraggable({
        id: card.id,
        data: { card }
    });

    // fan math
    const maxAngle = 18;
    const radius = 260;
    const center = (total - 1) / 2;
    const offset = index - center;

    const angle = total > 3 ? (offset / center) * maxAngle : 0;
    const rad = (angle * Math.PI) / 180;

    const x = Math.sin(rad) * radius + offset * 60;
    const y = -Math.cos(rad) * radius;

    const CARD_WIDTH = 180;

    const style = dragging
        ? {}
        : {
            transform: `
                translate(${x - CARD_WIDTH / 2}px, ${y}px)
                rotate(${angle}deg)
                scale(0.7)
            `,
            zIndex: 20 + index
        };

    return (
        <div
            ref={setNodeRef}
            className={`hand-card ${dragging ? "dragging" : ""}`}
            style={style}
            {...(!dragging ? attributes : {})}
            {...(!dragging ? listeners : {})}
        >
            <img src={card.image} alt={card.name} />
            <div className="card-name">{card.name}</div>
        </div>
    );
}
