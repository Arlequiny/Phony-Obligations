import { DndContext, DragOverlay } from "@dnd-kit/core";
import { useState } from "react";
import HandCard from "./HandCard";
import "./Hand.css";

export default function Hand({ cards }) {
    const [activeCard, setActiveCard] = useState(null);

    return (
        <DndContext
            onDragStart={(e) => setActiveCard(e.active.data.current.card)}
            onDragEnd={() => setActiveCard(null)}
            onDragCancel={() => setActiveCard(null)}
        >
            <div className="hand-zone">
                <div className="hand-container">
                    {cards.map((card, index) => (
                        <HandCard
                            key={card.id}
                            card={card}
                            index={index}
                            total={cards.length}
                        />
                    ))}
                </div>
            </div>

            <DragOverlay>
                {activeCard ? (
                    <HandCard card={activeCard} dragging />
                ) : null}
            </DragOverlay>
        </DndContext>
    );
}
