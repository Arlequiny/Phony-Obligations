import "./Hand.css";
import HandCard from "./HandCard";

export default function Hand({ cards }) {
    const radius = 260;
    const baseScale = 0.75;
    const maxAngle = 18;
    const spacing = 50;

    const count = cards.length;
    const centerIndex = (count - 1) / 2;
    const useRotation = count > 3;

    return (
        <div className="hand-root">
            <div className="hand-zone">
                <div className="hand-anchor">
                    {cards.map((card, index) => {
                        const offset = index - centerIndex;
                        const angle = useRotation
                            ? (offset / centerIndex) * maxAngle
                            : 0;

                        const rad = (angle * Math.PI) / 180;
                        const x =  Math.sin(rad) * radius + offset * spacing;
                        const y = -Math.cos(rad) * radius;

                        return (
                            <HandCard
                                key={card.id}
                                card={card}
                                baseScale={baseScale}
                                layout={{
                                    x,
                                    y,
                                    angle,
                                    zIndex: 20 + index
                                }}
                            />
                        );
                    })}
                </div>
            </div>
        </div>
    );
}