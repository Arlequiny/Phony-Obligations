import { useDraggable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { useState } from "react";
import "./HandCard.css";

export default function HandCard({ card, layout, baseScale }) {
    const [focused, setFocused] = useState(false);

    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        isDragging
    } = useDraggable({
        id: card.id,
        data: { from: "hand", card }
    });

    let transformString;

    if (isDragging) {
        transformString = `
        ${CSS.Translate.toString(transform)}
        scale(${baseScale})
    `;
    }
    else if (focused) {
        transformString = `
            translate(${layout.x}px, ${layout.y}px)
            rotate(0deg)
            scale(1)
        `;
    }
    else {
        transformString = `
            translate(${layout.x}px, ${layout.y}px)
            rotate(${layout.angle}deg)
            scale(${baseScale})
        `;
    }

    return (
        <div
            ref={setNodeRef}
            {...attributes}
            {...listeners}
            className={`hand-card ${focused ? "focused" : ""} ${isDragging ? "dragging" : ""}`}
            style={{
                transform: transformString,
                zIndex: focused || isDragging ? 29 : layout.zIndex
            }}
            onMouseEnter={() => setFocused(true)}
            onMouseLeave={() => setFocused(false)}
        >
            <img src={card.image} alt={card.name} />
            <div className="card-name">{card.name}</div>

            <div className="stat attack">{card.attack}</div>
            <div className="stat health">{card.health}</div>
            {card.armor > 0 && <div className="stat armor">{card.armor}</div>}
        </div>
    );
}